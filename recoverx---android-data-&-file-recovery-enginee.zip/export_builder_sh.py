import json

with open("android_files_b64.json") as f:
    files_map = json.load(f)

script = """#!/bin/bash
set -e
echo "=== Menguraikan 35 File Sumber Asli Jetpack Compose & Kotlin RecoverX ==="

mkdir -p android

python3 -c '
import os, base64, json

files = """ + json.dumps(files_map) + """

for path, b64content in files.items():
    full_path = os.path.join("android", path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "wb") as f:
        f.write(base64.b64decode(b64content))

print("Seluruh 35 berkas Kotlin & Jetpack Compose asli berhasil dibuat!")
'

echo "=== Memulai Build APK Debug Asli ==="
"""

with open("build-android-full.sh", "w") as out:
    out.write(script)

print("Generated build-android-full.sh successfully!")
