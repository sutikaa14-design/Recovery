import os, json

files_to_push = []
# 1. Android folder
for root, dirs, files in os.walk('android'):
    for f in files:
        p = os.path.join(root, f)
        files_to_push.append(p)

print(f"Total android files: {len(files_to_push)}")
