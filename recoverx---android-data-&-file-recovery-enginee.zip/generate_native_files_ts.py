import os, json

base_dir = "android"
files_data = []

for root, dirs, files in os.walk(base_dir):
    for f in sorted(files):
        if f.endswith('.zip') or f.endswith('.jar'):
            continue
        full_path = os.path.join(root, f)
        rel_path = os.path.relpath(full_path, base_dir)
        try:
            with open(full_path, 'r', encoding='utf-8') as cf:
                content = cf.read()
                desc = f"File {f} ({rel_path})"
                if "MainActivity" in f:
                    desc = "Activity utama dengan Jetpack Compose & SAF Recovery"
                elif "HomeScreen" in f:
                    desc = "Layar utama Jetpack Compose dengan Storage Meter & Tombol Scan"
                elif "ScanningScreen" in f:
                    desc = "Layar animasi pemindaian real-time biner & radar"
                elif "FoundFilesScreen" in f:
                    desc = "Daftar berkas ditemukan dengan filter kategori foto, video, dokumen"
                elif "RecoveryViewModel" in f:
                    desc = "ViewModel arsitektur MVI/MVVM mengelola state pemindaian"
                elif "FileSignatureEngine" in f:
                    desc = "Mesin biner carving Magic Number & Header/Footer"
                elif "StoragePermissionHelper" in f:
                    desc = "Manajemen izin MANAGE_EXTERNAL_STORAGE Android 11-14"
                
                files_data.append({
                    "path": rel_path,
                    "description": desc,
                    "content": content
                })
        except Exception as e:
            pass

ts_content = """export interface AndroidProjectFile {
  path: string;
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = """ + json.dumps(files_data, indent=2) + ";\n"

with open("src/engine/androidProjectFiles.ts", "w", encoding="utf-8") as out:
    out.write(ts_content)

print(f"Generated androidProjectFiles.ts with {len(files_data)} authentic native files!")
