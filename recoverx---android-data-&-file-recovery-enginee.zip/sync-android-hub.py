import os, json

base_dir = "android"
result = []

for root, dirs, files in os.walk(base_dir):
    for f in files:
        if f.endswith('.zip') or f.endswith('.jar'):
            continue
        full_path = os.path.join(root, f)
        rel_path = os.path.relpath(full_path, base_dir)
        try:
            with open(full_path, 'r', encoding='utf-8') as content_file:
                content = content_file.read()
                result.append({
                    "path": rel_path,
                    "description": f"Native file: {rel_path}",
                    "content": content
                })
        except Exception as e:
            pass

print(f"Loaded {len(result)} files from android folder")
