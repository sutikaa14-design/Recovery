rm -rf test_out
mkdir -p test_out
cd test_out
bash ../build-android-full.sh
find android -type f | wc -l
cd ..
rm -rf test_out
