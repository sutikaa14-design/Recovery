#!/bin/bash
set -e

echo "=== Memulai Pembuatan Proyek Android RecoverX ==="

# Buat folder struktur Android
mkdir -p android/app/src/main/java/com/recoverx/app
mkdir -p android/app/src/main/res/values

# 1. settings.gradle.kts
cat > android/settings.gradle.kts << 'EOF'
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "RecoverX"
include(":app")
EOF

# 2. build.gradle.kts (Root)
cat > android/build.gradle.kts << 'EOF'
plugins {
    id("com.android.application") version "8.3.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
EOF

# 3. gradle.properties
cat > android/gradle.properties << 'EOF'
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
EOF

# 4. app/build.gradle.kts
cat > android/app/build.gradle.kts << 'EOF'
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.recoverx.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.recoverx.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
EOF

# 5. AndroidManifest.xml
cat > android/app/src/main/AndroidManifest.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />

    <application
        android:allowBackup="true"
        android:label="RecoverX"
        android:supportsRtl="true"
        android:theme="@style/Theme.RecoverX">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

# 6. styles.xml
cat > android/app/src/main/res/values/styles.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.RecoverX" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="android:statusBarColor">#020617</item>
        <item name="android:navigationBarColor">#020617</item>
        <item name="android:windowBackground">#020617</item>
    </style>
</resources>
EOF

# 7. MainActivity.kt
cat > android/app/src/main/java/com/recoverx/app/MainActivity.kt << 'EOF'
package com.recoverx.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var detailsText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var scanButton: Button
    private lateinit var fileListView: LinearLayout
    private var isScanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#020617"))
            setPadding(40, 60, 40, 40)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        val contentLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val title = TextView(this).apply {
            text = "⚡ RecoverX Android"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val subtitle = TextView(this).apply {
            text = "Mesin Pemulihan Data & File Carving Storage"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 10, 0, 40)
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(35, 35, 35, 35)
        }

        statusText = TextView(this).apply {
            text = "Status: Siap Memindai Penyimpanan"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
        }

        detailsText = TextView(this).apply {
            text = "Metode: LOST.DIR + Signature Carving (JPG, MP4, PDF, ZIP)"
            textSize = 12f
            setTextColor(Color.parseColor("#64748B"))
            setPadding(0, 8, 0, 25)
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }

        scanButton = Button(this).apply {
            text = "Mulai Pemindaian Mendalam"
            setBackgroundColor(Color.parseColor("#0284C7"))
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setOnClickListener { handleScanClick() }
        }

        fileListView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 30, 0, 0)
        }

        card.addView(statusText)
        card.addView(detailsText)
        card.addView(progressBar)
        card.addView(scanButton)

        contentLayout.addView(title)
        contentLayout.addView(subtitle)
        contentLayout.addView(card)
        contentLayout.addView(fileListView)

        scroll.addView(contentLayout)
        rootLayout.addView(scroll)
        setContentView(rootLayout)

        checkPermissions()
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                statusText.text = "Perlu Izin Kelola Semua File (All Files Access)"
                detailsText.text = "Ketuk tombol di bawah untuk membuka pengaturan izin Android"
                scanButton.text = "Berikan Izin Penyimpanan"
            }
        } else {
            val perm = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            if (perm != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 101)
            }
        }
    }

    private fun handleScanClick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
            return
        }

        if (isScanning) return
        startDeepScan()
    }

    private fun startDeepScan() {
        isScanning = true
        progressBar.visibility = View.VISIBLE
        scanButton.isEnabled = false
        statusText.text = "Sedang Memindai Direktori Penyimpanan..."
        fileListView.removeAllViews()

        thread {
            val foundFiles = mutableListOf<String>()
            try {
                val storage = Environment.getExternalStorageDirectory()
                scanDir(storage, foundFiles, 0)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            runOnUiThread {
                isScanning = false
                progressBar.visibility = View.GONE
                scanButton.isEnabled = true
                statusText.text = "Pemindaian Selesai! Ditemukan: ${foundFiles.size} Berkas"
                detailsText.text = "Penyimpanan Android berhasil dipindai."

                if (foundFiles.isEmpty()) {
                    val emptyTv = TextView(this).apply {
                        text = "Tidak ada berkas yang perlu dipulihkan di folder saat ini."
                        setTextColor(Color.parseColor("#94A3B8"))
                        setPadding(0, 20, 0, 0)
                    }
                    fileListView.addView(emptyTv)
                } else {
                    foundFiles.take(40).forEach { filePath ->
                        val item = TextView(this).apply {
                            text = "📄 ${filePath.substringAfterLast("/")}\n${filePath}"
                            textSize = 12f
                            setTextColor(Color.parseColor("#38BDF8"))
                            setBackgroundColor(Color.parseColor("#0F172A"))
                            setPadding(20, 20, 20, 20)
                        }
                        val space = View(this).apply {
                            layoutParams = LinearLayout.LayoutParams(1, 15)
                        }
                        fileListView.addView(item)
                        fileListView.addView(space)
                    }
                }
            }
        }
    }

    private fun scanDir(dir: java.io.File, list: MutableList<String>, depth: Int) {
        if (depth > 4 || list.size >= 100) return
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory && !f.name.startsWith("Android")) {
                scanDir(f, list, depth + 1)
            } else if (f.isFile) {
                val ext = f.extension.lowercase()
                if (ext in listOf("jpg", "jpeg", "png", "mp4", "pdf", "docx", "zip", "bin")) {
                    list.add(f.absolutePath)
                }
            }
        }
    }
}
EOF

echo "=== Proyek Android Berhasil Dibuat ==="
