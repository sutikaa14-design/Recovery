/**
 * RecoverX File Carving Engine (TypeScript / Web & Android Parity)
 * Performs real binary signature inspection and carving on byte arrays,
 * slices, streams, and files.
 */

export interface CarvedFile {
  id: string;
  name: string;
  originalPath: string;
  blob?: Blob;
  dataUrl?: string;
  category: 'PHOTOS' | 'VIDEOS' | 'AUDIO' | 'DOCUMENTS' | 'ARCHIVES' | 'APKS' | 'OTHERS';
  mimeType: string;
  extension: string;
  sizeBytes: number;
  source: 'MEDIASTORE_TRASH' | 'LOST_DIR' | 'FILE_CARVING' | 'HIDDEN_CACHE' | 'APP_ORPHAN';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  headerOffset: number;
  timestamp: number;
  hexHeader: string;
  sha256?: string;
  isSelected?: boolean;
}

// Byte signatures
const JPEG_SOI = [0xFF, 0xD8, 0xFF];
const PNG_MAGIC = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
const PDF_MAGIC = [0x25, 0x50, 0x44, 0x46, 0x2D]; // %PDF-
const ZIP_MAGIC = [0x50, 0x4B, 0x03, 0x04]; // PK\x03\x04
const RIFF_MAGIC = [0x52, 0x49, 0x46, 0x46]; // RIFF
const MP3_ID3 = [0x49, 0x44, 0x33]; // ID3
const OGG_MAGIC = [0x4F, 0x67, 0x67, 0x53]; // OggS

function matches(buffer: Uint8Array, offset: number, target: number[]): boolean {
  if (buffer.length - offset < target.length) return false;
  for (let i = 0; i < target.length; i++) {
    if (buffer[offset + i] !== target[i]) return false;
  }
  return true;
}

export function toHexDump(buffer: Uint8Array, length: number = 16): string {
  const slice = buffer.slice(0, Math.min(buffer.length, length));
  return Array.from(slice)
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join(' ');
}

export async function computeSHA256(buffer: ArrayBuffer): Promise<string> {
  if (window.crypto && window.crypto.subtle) {
    try {
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', buffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch {
      return 'hash_unsupported';
    }
  }
  return 'sha256_mock_env';
}

export interface SignatureDetection {
  extension: string;
  mimeType: string;
  category: 'PHOTOS' | 'VIDEOS' | 'AUDIO' | 'DOCUMENTS' | 'ARCHIVES' | 'APKS' | 'OTHERS';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  signatureName: string;
  detectedLength: number;
}

export function identifyBinarySignature(bytes: Uint8Array): SignatureDetection | null {
  if (bytes.length < 8) return null;

  // 1. JPEG Check
  if (bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
    // Search for EOI (FF D9)
    let eoi = -1;
    for (let i = 2; i < bytes.length - 1; i++) {
      if (bytes[i] === 0xFF && bytes[i + 1] === 0xD9) {
        eoi = i + 2;
      }
    }
    return {
      extension: 'jpg',
      mimeType: 'image/jpeg',
      category: 'PHOTOS',
      confidence: eoi > 0 ? 'HIGH' : 'MEDIUM',
      signatureName: 'JPEG Image (SOI/EOI)',
      detectedLength: eoi > 0 ? eoi : bytes.length
    };
  }

  // 2. PNG Check
  if (matches(bytes, 0, PNG_MAGIC)) {
    return {
      extension: 'png',
      mimeType: 'image/png',
      category: 'PHOTOS',
      confidence: 'HIGH',
      signatureName: 'PNG Image',
      detectedLength: bytes.length
    };
  }

  // 3. MP4 / MOV / 3GP Check (ftyp atom at byte 4)
  if (bytes.length >= 12 &&
      bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) {
    const ftypSize = (bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
    const brand = String.fromCharCode(...bytes.slice(8, 12));
    const ext = brand.startsWith('3g') ? '3gp' : brand === 'qt  ' ? 'mov' : 'mp4';
    return {
      extension: ext,
      mimeType: ext === '3gp' ? 'video/3gpp' : ext === 'mov' ? 'video/quicktime' : 'video/mp4',
      category: 'VIDEOS',
      confidence: 'HIGH',
      signatureName: `ISO Media Video (${brand.trim()})`,
      detectedLength: Math.max(ftypSize, bytes.length)
    };
  }

  // 4. PDF Check
  if (matches(bytes, 0, PDF_MAGIC)) {
    return {
      extension: 'pdf',
      mimeType: 'application/pdf',
      category: 'DOCUMENTS',
      confidence: 'HIGH',
      signatureName: 'PDF Document',
      detectedLength: bytes.length
    };
  }

  // 5. ZIP / APK / Office XML
  if (matches(bytes, 0, ZIP_MAGIC)) {
    // Check if contains AndroidManifest.xml (APK)
    const textSlice = String.fromCharCode(...bytes.slice(0, Math.min(bytes.length, 2048)));
    const isApk = textSlice.includes('AndroidManifest.xml');
    const isDocx = textSlice.includes('word/');
    const isXlsx = textSlice.includes('xl/');

    if (isApk) {
      return {
        extension: 'apk',
        mimeType: 'application/vnd.android.package-archive',
        category: 'APKS',
        confidence: 'HIGH',
        signatureName: 'Android APK Package',
        detectedLength: bytes.length
      };
    } else if (isDocx) {
      return {
        extension: 'docx',
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        category: 'DOCUMENTS',
        confidence: 'HIGH',
        signatureName: 'Microsoft Word (DOCX)',
        detectedLength: bytes.length
      };
    } else if (isXlsx) {
      return {
        extension: 'xlsx',
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        category: 'DOCUMENTS',
        confidence: 'HIGH',
        signatureName: 'Microsoft Excel (XLSX)',
        detectedLength: bytes.length
      };
    }

    return {
      extension: 'zip',
      mimeType: 'application/zip',
      category: 'ARCHIVES',
      confidence: 'HIGH',
      signatureName: 'ZIP Archive',
      detectedLength: bytes.length
    };
  }

  // 6. RIFF (WebP / WAV)
  if (matches(bytes, 0, RIFF_MAGIC) && bytes.length >= 12) {
    const type = String.fromCharCode(...bytes.slice(8, 12));
    if (type === 'WEBP') {
      return {
        extension: 'webp',
        mimeType: 'image/webp',
        category: 'PHOTOS',
        confidence: 'HIGH',
        signatureName: 'WebP Image',
        detectedLength: bytes.length
      };
    }
    if (type === 'WAVE') {
      return {
        extension: 'wav',
        mimeType: 'audio/wav',
        category: 'AUDIO',
        confidence: 'HIGH',
        signatureName: 'WAV Audio',
        detectedLength: bytes.length
      };
    }
  }

  // 7. MP3 ID3
  if (matches(bytes, 0, MP3_ID3)) {
    return {
      extension: 'mp3',
      mimeType: 'audio/mpeg',
      category: 'AUDIO',
      confidence: 'HIGH',
      signatureName: 'MP3 Audio (ID3v2)',
      detectedLength: bytes.length
    };
  }

  // 8. OGG
  if (matches(bytes, 0, OGG_MAGIC)) {
    return {
      extension: 'ogg',
      mimeType: 'audio/ogg',
      category: 'AUDIO',
      confidence: 'MEDIUM',
      signatureName: 'OGG Stream',
      detectedLength: bytes.length
    };
  }

  return null;
}

export function formatBytes(bytes: number): string {
  if (bytes <= 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}
