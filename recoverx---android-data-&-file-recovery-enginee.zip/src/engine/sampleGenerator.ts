import { CarvedFile, computeSHA256, toHexDump } from './carver';

/**
 * Creates genuine binary files (valid JPEG, PNG, PDF, ZIP byte structures)
 * so that tests perform REAL byte analysis, true image decoding, and genuine SHA-256 calculation.
 */
export async function generateGenuineSampleFiles(): Promise<CarvedFile[]> {
  const files: CarvedFile[] = [];

  // 1. Genuine 1x1 Red JPEG with valid SOI, APP0 (JFIF), DQT, SOF0, DHT, SOS, and EOI
  const jpegBytes = new Uint8Array([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48,
    0x00, 0x48, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
    0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
    0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
    0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
    0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
    0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00, 0x01, 0x05, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04,
    0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F,
    0x00, 0x7F, 0x00, 0xFF, 0xD9
  ]);
  const jpegBlob = new Blob([jpegBytes], { type: 'image/jpeg' });
  const jpegSha = await computeSHA256(jpegBytes.buffer);

  files.push({
    id: 'sample_jpeg_1',
    name: 'DCIM_20240915_FamilyTrip.jpg',
    originalPath: '/storage/emulated/0/.trash/DCIM_20240915_FamilyTrip.jpg',
    blob: jpegBlob,
    dataUrl: URL.createObjectURL(jpegBlob),
    category: 'PHOTOS',
    mimeType: 'image/jpeg',
    extension: 'jpg',
    sizeBytes: jpegBytes.length,
    source: 'MEDIASTORE_TRASH',
    confidence: 'HIGH',
    headerOffset: 0,
    timestamp: Date.now() - 86400000 * 3,
    hexHeader: toHexDump(jpegBytes, 16),
    sha256: jpegSha,
    isSelected: true
  });

  // 2. Genuine PNG 1x1 Cyan Pixel
  const pngBytes = new Uint8Array([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x60, 0xF8, 0xCF, 0xC0,
    0x00, 0x00, 0x03, 0x01, 0x01, 0x00, 0x18, 0xDD, 0x8D, 0xB0, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45,
    0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82
  ]);
  const pngBlob = new Blob([pngBytes], { type: 'image/png' });
  const pngSha = await computeSHA256(pngBytes.buffer);

  files.push({
    id: 'sample_png_2',
    name: 'LOST_14092_Screenshot.png',
    originalPath: '/storage/emulated/0/LOST.DIR/14092',
    blob: pngBlob,
    dataUrl: URL.createObjectURL(pngBlob),
    category: 'PHOTOS',
    mimeType: 'image/png',
    extension: 'png',
    sizeBytes: pngBytes.length,
    source: 'LOST_DIR',
    confidence: 'HIGH',
    headerOffset: 0,
    timestamp: Date.now() - 86400000 * 5,
    hexHeader: toHexDump(pngBytes, 16),
    sha256: pngSha,
    isSelected: true
  });

  // 3. Genuine PDF Document with %PDF-1.4 header and %%EOF trailer
  const pdfString = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 144] /Contents 4 0 R >>
endobj
4 0 obj
<< /Length 55 >>
stream
BT /F1 12 Tf 50 100 Td (RecoverX Restored Document) Tj ET
endstream
endobj
xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000204 00000 n 
trailer
<< /Size 5 /Root 1 0 R >>
startxref
310
%%EOF`;
  const pdfBytes = new TextEncoder().encode(pdfString);
  const pdfBlob = new Blob([pdfBytes], { type: 'application/pdf' });
  const pdfSha = await computeSHA256(pdfBytes.buffer);

  files.push({
    id: 'sample_pdf_3',
    name: 'Kontrak_Kerja_Recovered.pdf',
    originalPath: '/storage/emulated/0/Download/.trash/Kontrak_Kerja_Recovered.pdf',
    blob: pdfBlob,
    dataUrl: URL.createObjectURL(pdfBlob),
    category: 'DOCUMENTS',
    mimeType: 'application/pdf',
    extension: 'pdf',
    sizeBytes: pdfBytes.length,
    source: 'MEDIASTORE_TRASH',
    confidence: 'HIGH',
    headerOffset: 0,
    timestamp: Date.now() - 86400000 * 1,
    hexHeader: toHexDump(pdfBytes, 16),
    sha256: pdfSha,
    isSelected: false
  });

  // 4. Genuine WebP image
  const webpBytes = new Uint8Array([
    0x52, 0x49, 0x46, 0x46, 0x1A, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50, 0x56, 0x50, 0x38, 0x4C,
    0x0E, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x00, 0x07, 0x10, 0xF1, 0x01, 0x00, 0x00, 0x00
  ]);
  const webpBlob = new Blob([webpBytes], { type: 'image/webp' });
  const webpSha = await computeSHA256(webpBytes.buffer);

  files.push({
    id: 'sample_webp_4',
    name: 'Whatsapp_Sticker_Cache.webp',
    originalPath: '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.trash/Sticker_882.webp',
    blob: webpBlob,
    dataUrl: URL.createObjectURL(webpBlob),
    category: 'PHOTOS',
    mimeType: 'image/webp',
    extension: 'webp',
    sizeBytes: webpBytes.length,
    source: 'HIDDEN_CACHE',
    confidence: 'HIGH',
    headerOffset: 0,
    timestamp: Date.now() - 86400000 * 2,
    hexHeader: toHexDump(webpBytes, 16),
    sha256: webpSha,
    isSelected: false
  });

  return files;
}
