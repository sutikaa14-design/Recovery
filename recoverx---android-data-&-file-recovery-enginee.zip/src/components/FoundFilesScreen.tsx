import React from 'react';
import { 
  ArrowLeft, Search, CheckSquare, Square, ChevronRight,
  Image as ImageIcon, Video, Music, FileText, Archive, Smartphone, Download,
  CheckCircle2, Sparkles
} from 'lucide-react';
import { CarvedFile, formatBytes } from '../engine/carver';

interface FoundFilesScreenProps {
  files: CarvedFile[];
  searchQuery: string;
  selectedCategory: string | null;
  onSearchChange: (q: string) => void;
  onSelectCategory: (cat: string | null) => void;
  onToggleSelect: (id: string) => void;
  onToggleSelectAll: () => void;
  onOpenFilePreview: (file: CarvedFile) => void;
  onStartRecovery: () => void;
  onBack: () => void;
}

export const FoundFilesScreen: React.FC<FoundFilesScreenProps> = ({
  files,
  searchQuery,
  selectedCategory,
  onSearchChange,
  onSelectCategory,
  onToggleSelect,
  onToggleSelectAll,
  onOpenFilePreview,
  onStartRecovery,
  onBack
}) => {
  const filtered = files.filter(f => {
    const matchesCat = !selectedCategory || f.category === selectedCategory;
    const matchesQuery = !searchQuery || f.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  const selectedFiles = files.filter(f => f.isSelected);
  const selectedCount = selectedFiles.length;
  const selectedBytes = selectedFiles.reduce((acc, cur) => acc + cur.sizeBytes, 0);
  const isAllSelected = files.length > 0 && selectedCount === files.length;

  const categories = [
    { key: null, label: `Semua (${files.length})` },
    { key: 'PHOTOS', label: `Foto (${files.filter(f => f.category === 'PHOTOS').length})` },
    { key: 'VIDEOS', label: `Video (${files.filter(f => f.category === 'VIDEOS').length})` },
    { key: 'AUDIO', label: `Audio (${files.filter(f => f.category === 'AUDIO').length})` },
    { key: 'DOCUMENTS', label: `Dokumen (${files.filter(f => f.category === 'DOCUMENTS').length})` },
    { key: 'ARCHIVES', label: `Arsip (${files.filter(f => f.category === 'ARCHIVES').length})` },
    { key: 'APKS', label: `APK (${files.filter(f => f.category === 'APKS').length})` },
  ];

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'PHOTOS': return <ImageIcon className="w-4 h-4 text-cyan-400" />;
      case 'VIDEOS': return <Video className="w-4 h-4 text-rose-400" />;
      case 'AUDIO': return <Music className="w-4 h-4 text-purple-400" />;
      case 'DOCUMENTS': return <FileText className="w-4 h-4 text-blue-400" />;
      case 'ARCHIVES': return <Archive className="w-4 h-4 text-amber-400" />;
      case 'APKS': return <Smartphone className="w-4 h-4 text-emerald-400" />;
      default: return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  const getSourceLabel = (src: string) => {
    switch (src) {
      case 'MEDIASTORE_TRASH': return 'Trash';
      case 'LOST_DIR': return 'LOST.DIR';
      case 'FILE_CARVING': return 'Carved';
      case 'HIDDEN_CACHE': return 'Cache';
      default: return 'Orphan';
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between">
      <div className="p-4 sm:p-5 space-y-3.5 flex-1 overflow-y-auto">
        {/* Top Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-300 transition cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">File Ditemukan</h2>
              <p className="text-[11px] text-slate-400">{files.length} file nyata dapat dipulihkan</p>
            </div>
          </div>

          <button
            onClick={onToggleSelectAll}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition cursor-pointer"
          >
            {isAllSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
            <span>{isAllSelected ? 'Batal Semua' : 'Pilih Semua'}</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Cari nama file atau ekstensi (jpg, pdf, mp4)..."
            className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-500 outline-none transition"
          />
        </div>

        {/* Category Pills Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat, idx) => {
            const isSelected = selectedCategory === cat.key;
            return (
              <button
                key={idx}
                onClick={() => onSelectCategory(cat.key)}
                className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm shadow-cyan-500/30'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* File Results List */}
        {filtered.length === 0 ? (
          <div className="text-center py-14 space-y-2 text-slate-500">
            <Search className="w-8 h-8 mx-auto stroke-1" />
            <p className="text-xs font-medium">Tidak ada file yang cocok dengan kriteria</p>
          </div>
        ) : (
          <div className="space-y-2 pb-20">
            {filtered.map((item) => (
              <div
                key={item.id}
                className={`p-3 rounded-2xl border transition flex items-center gap-3 cursor-pointer ${
                  item.isSelected
                    ? 'bg-slate-800/90 border-cyan-500 shadow-sm shadow-cyan-950/20'
                    : 'bg-slate-900/70 border-slate-800/80 hover:bg-slate-800/40'
                }`}
                onClick={() => onOpenFilePreview(item)}
              >
                {/* Select Checkbox */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSelect(item.id);
                  }}
                  className="p-1 hover:text-cyan-400 text-slate-400 transition"
                >
                  {item.isSelected ? (
                    <CheckSquare className="w-4 h-4 text-cyan-400 fill-cyan-400/20" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-600" />
                  )}
                </button>

                {/* File Thumbnail or Category Icon */}
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700/60 overflow-hidden flex items-center justify-center shrink-0">
                  {item.category === 'PHOTOS' && item.dataUrl ? (
                    <img src={item.dataUrl} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    getCategoryIcon(item.category)
                  )}
                </div>

                {/* File Information */}
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-semibold text-white truncate">{item.name}</h4>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                    <span className="font-mono">{formatBytes(item.sizeBytes)}</span>
                    <span>•</span>
                    <span className="px-1.5 py-0.2 rounded bg-slate-800 font-mono text-[10px] text-cyan-300">
                      {getSourceLabel(item.source)}
                    </span>
                    {item.confidence === 'HIGH' && (
                      <span className="text-[10px] font-semibold text-emerald-400 flex items-center gap-0.5">
                        <CheckCircle2 className="w-3 h-3 inline" /> 100% Utuh
                      </span>
                    )}
                  </div>
                </div>

                {/* Open Preview Chevron */}
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sticky Bottom Action Bar */}
      {selectedCount > 0 && (
        <div className="sticky bottom-0 bg-slate-900/95 border-t border-slate-800 p-4 backdrop-blur flex items-center justify-between z-30">
          <div>
            <div className="text-xs font-bold text-white">{selectedCount} File Terpilih</div>
            <div className="text-[11px] font-mono text-cyan-400">{formatBytes(selectedBytes)}</div>
          </div>

          <button
            onClick={onStartRecovery}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-cyan-500/20 transition cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Pulihkan Sekarang</span>
          </button>
        </div>
      )}
    </div>
  );
};
