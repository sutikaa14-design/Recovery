import os, base64, json

base_dir = "android"
all_files = {}

for root, dirs, files in os.walk(base_dir):
    for f in sorted(files):
        if f.endswith('.zip') or f.endswith('.jar'):
            continue
        full_path = os.path.join(root, f)
        rel_path = os.path.relpath(full_path, base_dir)
        with open(full_path, 'rb') as fp:
            all_files[rel_path] = base64.b64encode(fp.read()).decode('utf-8')

with open("android_files_b64.json", "w") as out:
    json.dump(all_files, out)

print(f"Total encoded files: {len(all_files)}, json size: {os.path.getsize('android_files_b64.json')}")
