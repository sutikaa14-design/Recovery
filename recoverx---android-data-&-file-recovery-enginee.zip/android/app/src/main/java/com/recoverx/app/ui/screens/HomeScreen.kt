package com.recoverx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.recoverx.app.ui.theme.*
import com.recoverx.app.ui.viewmodel.ScanMode
import com.recoverx.app.ui.viewmodel.UiState

@Composable
fun HomeScreen(
    state: UiState,
    onStartScan: () -> Unit,
    onSelectMode: (ScanMode) -> Unit,
    onRequestPermission: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        // Top App Brand Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyanPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = "RecoverX Logo",
                            tint = DarkBackground
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "RecoverX",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
                Text(
                    text = "Mesin Pemulihan Data Fisik Android",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Engine Status Pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (state.permissionStatus.hasAllFilesAccess) AccentGreen.copy(alpha = 0.15f) else AccentAmber.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (state.permissionStatus.hasAllFilesAccess) AccentGreen else AccentAmber
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (state.permissionStatus.hasAllFilesAccess) AccentGreen else AccentAmber)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.permissionStatus.hasAllFilesAccess) "All Files OK" else "Scoped Only",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.permissionStatus.hasAllFilesAccess) AccentGreen else AccentAmber
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Storage Volume Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263238))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SdStorage,
                            contentDescription = null,
                            tint = CyanPrimary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Penyimpanan Utama",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = state.storageVolumes.firstOrNull()?.path ?: "/storage/emulated/0",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                val primaryVolume = state.storageVolumes.firstOrNull()
                val totalGb = if (primaryVolume != null && primaryVolume.totalBytes > 0) {
                    primaryVolume.totalBytes / (1024 * 1024 * 1024)
                } else 128L
                val freeGb = if (primaryVolume != null && primaryVolume.freeBytes > 0) {
                    primaryVolume.freeBytes / (1024 * 1024 * 1024)
                } else 42L
                val usedGb = (totalGb - freeGb).coerceAtLeast(0L)
                val usedRatio = if (totalGb > 0) usedGb.toFloat() / totalGb.toFloat() else 0.65f

                LinearProgressIndicator(
                    progress = usedRatio,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = CyanPrimary,
                    trackColor = DarkSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Terpakai: $usedGb GB / $totalGb GB",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Text(
                        text = "Tersedia: $freeGb GB",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = CyanLight
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Honest Android Storage & Carving Info Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E2E)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3A5F))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    tint = CyanLight,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Teknologi Pemulihan Nyata (Tanpa Tipuan)",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "RecoverX menggunakan algoritma file carving sejati (analisis signature byte SOI/EOI, RIFF, ftyp, PK) pada MediaStore, recycle bin sistem, cache internal, dan LOST.DIR tanpa memerlukan root.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Scan Mode Selection
        Text(
            text = "Pilih Metode Pemindaian",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScanModeCard(
            title = ScanMode.FULL_DEEP_SCAN.title,
            description = ScanMode.FULL_DEEP_SCAN.description,
            icon = Icons.Default.Radar,
            isSelected = state.selectedScanMode == ScanMode.FULL_DEEP_SCAN,
            isRecommended = true,
            onClick = { onSelectMode(ScanMode.FULL_DEEP_SCAN) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        ScanModeCard(
            title = ScanMode.MEDIASTORE_TRASH.title,
            description = ScanMode.MEDIASTORE_TRASH.description,
            icon = Icons.Default.DeleteOutline,
            isSelected = state.selectedScanMode == ScanMode.MEDIASTORE_TRASH,
            isRecommended = false,
            onClick = { onSelectMode(ScanMode.MEDIASTORE_TRASH) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        ScanModeCard(
            title = ScanMode.LOST_DIR_RECOVERY.title,
            description = ScanMode.LOST_DIR_RECOVERY.description,
            icon = Icons.Default.FolderSpecial,
            isSelected = state.selectedScanMode == ScanMode.LOST_DIR_RECOVERY,
            isRecommended = false,
            onClick = { onSelectMode(ScanMode.LOST_DIR_RECOVERY) }
        )

        Spacer(modifier = Modifier.height(30.dp))

        // CTA Start Deep Scan Button
        Button(
            onClick = {
                if (!state.permissionStatus.hasAllFilesAccess && !state.permissionStatus.hasMediaImagesAccess) {
                    onRequestPermission()
                } else {
                    onStartScan()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanPrimary,
                contentColor = DarkBackground
            )
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Mulai Pemindaian Mandiri",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun ScanModeCard(
    title: String,
    description: String,
    icon: ImageVector,
    isSelected: Boolean,
    isRecommended: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DarkSurfaceVariant else DarkSurface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isSelected) CyanPrimary else Color(0xFF1E293B)
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) CyanPrimary.copy(alpha = 0.2f) else Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) CyanPrimary else TextSecondary
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    if (isRecommended) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = CyanPrimary.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "REKOMENDASI",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanLight,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = description,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = CyanPrimary,
                    unselectedColor = TextSecondary
                )
            )
        }
    }
}
