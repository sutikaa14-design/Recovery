package com.recoverx.app.data.scanner

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import com.recoverx.app.data.model.FileSource
import com.recoverx.app.data.model.RecoverableFile
import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class MediaStoreTrashScanner(private val context: Context) {

    /**
     * Queries Android MediaStore for files that are in the system trash (IS_TRASHED=1),
     * pending files, or expired media entries.
     */
    fun scanTrashedMedia(): Flow<RecoverableFile> = flow {
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.DATA
        )

        var cursor: Cursor? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+ (API 30+) official MATCH_ONLY or MATCH_INCLUDE for system trash
                val queryArgs = Bundle().apply {
                    putInt(
                        MediaStore.QUERY_ARG_MATCH_TRASHED,
                        MediaStore.MATCH_ONLY
                    )
                    putString(
                        android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER,
                        "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
                    )
                }
                cursor = resolver.query(collection, projection, queryArgs, null)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10 (API 29) IS_TRASHED flag
                val selection = "${MediaStore.MediaColumns.IS_TRASHED} = 1"
                cursor = resolver.query(
                    collection,
                    projection,
                    selection,
                    null,
                    "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
                )
            }

            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val dataCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: "trashed_$id"
                    val mime = c.getString(mimeCol) ?: "application/octet-stream"
                    val size = c.getLong(sizeCol)
                    val date = c.getLong(dateCol) * 1000L
                    val path = c.getString(dataCol) ?: ""
                    val contentUri = ContentUris.withAppendedId(collection, id)

                    val ext = name.substringAfterLast('.', "")
                    val category = if (ext.isNotEmpty()) {
                        ScanCategory.fromExtension(ext)
                    } else {
                        ScanCategory.fromMimeType(mime)
                    }

                    emit(
                        RecoverableFile(
                            id = "mediastore_trash_$id",
                            name = name,
                            originalPath = path,
                            uri = contentUri,
                            category = category,
                            mimeType = mime,
                            extension = ext,
                            sizeBytes = size,
                            source = FileSource.MEDIASTORE_TRASH,
                            confidence = RecoveryConfidence.HIGH,
                            timestamp = date
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }.flowOn(Dispatchers.IO)
}
