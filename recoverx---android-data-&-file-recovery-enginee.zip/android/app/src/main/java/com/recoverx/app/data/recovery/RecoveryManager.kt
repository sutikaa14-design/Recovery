package com.recoverx.app.data.recovery

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import androidx.documentfile.provider.DocumentFile
import com.recoverx.app.data.model.RecoverableFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

data class RecoveryItemResult(
    val file: RecoverableFile,
    val isSuccess: Boolean,
    val restoredPath: String?,
    val restoredUri: Uri?,
    val bytesWritten: Long,
    val sha256Checksum: String?,
    val errorMessage: String? = null
)

data class BatchRecoverySummary(
    val totalCount: Int,
    val successCount: Int,
    val failedCount: Int,
    val totalBytesRestored: Long,
    val destinationFolder: String,
    val itemResults: List<RecoveryItemResult>
)

class RecoveryManager(private val context: Context) {

    /**
     * Recovers the selected files to either a user-selected SAF DocumentFolder
     * or the default safe public storage directory.
     */
    suspend fun recoverFiles(
        files: List<RecoverableFile>,
        targetTreeUri: Uri? = null,
        onProgress: (currentIndex: Int, currentFile: RecoverableFile, bytesWritten: Long) -> Unit
    ): BatchRecoverySummary = withContext(Dispatchers.IO) {
        val results = mutableListOf<RecoveryItemResult>()
        var totalBytes = 0L
        var successCount = 0
        var failedCount = 0

        // Determine destination folder
        val defaultOutputDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "RecoverX_Restored"
        )
        if (targetTreeUri == null && !defaultOutputDir.exists()) {
            defaultOutputDir.mkdirs()
        }

        val targetTreeDoc = if (targetTreeUri != null) {
            DocumentFile.fromTreeUri(context, targetTreeUri)
        } else null

        val destinationDesc = targetTreeDoc?.name ?: defaultOutputDir.absolutePath

        files.forEachIndexed { index, item ->
            onProgress(index, item, 0L)
            val result = restoreSingleFile(item, defaultOutputDir, targetTreeDoc) { bytes ->
                onProgress(index, item, bytes)
            }

            results.add(result)
            if (result.isSuccess) {
                successCount++
                totalBytes += result.bytesWritten

                // Notify Android MediaStore so Gallery / Photos app indexes the recovered file
                if (result.restoredPath != null) {
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(result.restoredPath),
                        arrayOf(item.mimeType),
                        null
                    )
                }
            } else {
                failedCount++
            }
        }

        BatchRecoverySummary(
            totalCount = files.size,
            successCount = successCount,
            failedCount = failedCount,
            totalBytesRestored = totalBytes,
            destinationFolder = destinationDesc,
            itemResults = results
        )
    }

    private fun restoreSingleFile(
        file: RecoverableFile,
        defaultFolder: File,
        targetDocDir: DocumentFile?,
        onByteChunk: (Long) -> Unit
    ): RecoveryItemResult {
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        var restoredPath: String? = null
        var restoredUri: Uri? = null

        try {
            // 1. Open input stream
            inputStream = if (file.uri != null) {
                context.contentResolver.openInputStream(file.uri)
            } else if (file.originalPath.isNotEmpty()) {
                val orig = File(file.originalPath)
                if (orig.exists() && orig.canRead()) {
                    FileInputStream(orig)
                } else null
            } else null

            if (inputStream == null) {
                return RecoveryItemResult(
                    file = file,
                    isSuccess = false,
                    restoredPath = null,
                    restoredUri = null,
                    bytesWritten = 0L,
                    sha256Checksum = null,
                    errorMessage = "Tidak dapat membuka sumber file (izin ditolak atau file terhapus secara fisik)"
                )
            }

            // Skip to carved offset if applicable
            if (file.headerOffset > 0) {
                inputStream.skip(file.headerOffset)
            }

            // 2. Open output stream in target destination
            val sanitizedName = sanitizeFileName(file.name, file.extension)
            if (targetDocDir != null && targetDocDir.canWrite()) {
                val newFile = targetDocDir.createFile(file.mimeType, sanitizedName)
                if (newFile != null) {
                    restoredUri = newFile.uri
                    outputStream = context.contentResolver.openOutputStream(newFile.uri)
                }
            } else {
                val outFile = File(defaultFolder, sanitizedName)
                restoredPath = outFile.absolutePath
                outputStream = FileOutputStream(outFile)
            }

            if (outputStream == null) {
                return RecoveryItemResult(
                    file = file,
                    isSuccess = false,
                    restoredPath = null,
                    restoredUri = null,
                    bytesWritten = 0L,
                    sha256Checksum = null,
                    errorMessage = "Tidak dapat membuat file tujuan pada penyimpanan terpilih"
                )
            }

            // 3. Stream bytes and compute SHA-256 hash
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            var bytesRead: Int
            var totalWritten = 0L
            val maxBytesToRead = if (file.length > 0) file.length else Long.MAX_VALUE

            while (totalWritten < maxBytesToRead) {
                val toRead = ((maxBytesToRead - totalWritten).coerceAtMost(buffer.size.toLong())).toInt()
                bytesRead = inputStream.read(buffer, 0, toRead)
                if (bytesRead == -1) break

                outputStream.write(buffer, 0, bytesRead)
                digest.update(buffer, 0, bytesRead)
                totalWritten += bytesRead
                onByteChunk(totalWritten)
            }

            outputStream.flush()

            val sha256 = digest.digest().joinToString("") { "%02x".format(it) }

            // Ensure we actually wrote data
            if (totalWritten == 0L) {
                return RecoveryItemResult(
                    file = file,
                    isSuccess = false,
                    restoredPath = null,
                    restoredUri = null,
                    bytesWritten = 0L,
                    sha256Checksum = null,
                    errorMessage = "Data kosong atau terkorupsi pada blok fisik"
                )
            }

            return RecoveryItemResult(
                file = file,
                isSuccess = true,
                restoredPath = restoredPath,
                restoredUri = restoredUri,
                bytesWritten = totalWritten,
                sha256Checksum = sha256
            )

        } catch (e: Exception) {
            return RecoveryItemResult(
                file = file,
                isSuccess = false,
                restoredPath = null,
                restoredUri = null,
                bytesWritten = 0L,
                sha256Checksum = null,
                errorMessage = e.message ?: "Kesalahan I/O saat pemulihan file"
            )
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { outputStream?.close() } catch (_: Exception) {}
        }
    }

    private fun sanitizeFileName(originalName: String, extension: String): String {
        val base = originalName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return if (!base.endsWith(".$extension", ignoreCase = true) && extension.isNotEmpty()) {
            "$base.$extension"
        } else {
            base
        }
    }
}
