package com.recoverx.app.data.scanner

import android.content.Context
import android.os.Environment
import com.recoverx.app.data.carving.FileSignatureEngine
import com.recoverx.app.data.model.FileSource
import com.recoverx.app.data.model.RecoverableFile
import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.io.File
import java.io.FileInputStream
import java.util.UUID

class HiddenStorageScanner(
    private val context: Context,
    private val signatureEngine: FileSignatureEngine
) {

    /**
     * Traverses physical locations where deleted or orphaned files linger:
     * - System & App Trash: .trash, .trashed, .Trash-1000
     * - LOST.DIR (Recovered filesystem clusters without extension)
     * - DCIM/.thumbnails and .cache directories
     * - Hidden messaging caches & .nomedia directories
     */
    fun scanHiddenAndLostDirectories(
        onPathInspected: (String) -> Unit
    ): Flow<RecoverableFile> = flow {
        val storageRoot = Environment.getExternalStorageDirectory()
        val targets = mutableListOf<File>()

        // 1. Target known hidden and trash directories
        val potentialFolders = listOf(
            File(storageRoot, ".trash"),
            File(storageRoot, ".trashed"),
            File(storageRoot, "LOST.DIR"),
            File(storageRoot, "DCIM/.thumbnails"),
            File(storageRoot, "Pictures/.thumbnails"),
            File(storageRoot, "Download/.trash"),
            File(storageRoot, "Android/media/com.whatsapp/WhatsApp/Media/.trash"),
            File(storageRoot, "Android/media/com.whatsapp/WhatsApp/Media/.Statuses"),
            File(storageRoot, "Telegram/Telegram Images"),
            File(storageRoot, "Telegram/Telegram Video"),
            File(storageRoot, "Android/data/${context.packageName}/cache"),
            context.cacheDir,
            context.externalCacheDir
        )

        for (folder in potentialFolders) {
            if (folder != null && folder.exists() && folder.canRead()) {
                targets.add(folder)
            }
        }

        // Also check root of SD Cards if any
        val sdCardDirs = context.getExternalFilesDirs(null)
        for (f in sdCardDirs) {
            val root = f?.parentFile?.parentFile?.parentFile?.parentFile
            if (root != null && root.exists() && root.canRead()) {
                val lostDir = File(root, "LOST.DIR")
                if (lostDir.exists() && lostDir.canRead()) {
                    targets.add(lostDir)
                }
            }
        }

        val buffer = ByteArray(4096)

        for (target in targets) {
            if (!currentCoroutineContext().isActive) break
            onPathInspected(target.absolutePath)

            target.walkTopDown()
                .maxDepth(4)
                .onEnter { dir ->
                    onPathInspected(dir.absolutePath)
                    currentCoroutineContext().isActive
                }
                .forEach { file ->
                    if (!currentCoroutineContext().isActive) return@forEach
                    if (file.isFile && file.length() > 0) {
                        onPathInspected(file.absolutePath)

                        val source = when {
                            file.absolutePath.contains("LOST.DIR") -> FileSource.LOST_DIR
                            file.absolutePath.contains(".trash") || file.absolutePath.contains(".trashed") -> FileSource.HIDDEN_CACHE
                            file.absolutePath.contains(".thumbnails") -> FileSource.HIDDEN_CACHE
                            else -> FileSource.APP_ORPHAN
                        }

                        // Inspect byte signature
                        var stream: FileInputStream? = null
                        try {
                            stream = FileInputStream(file)
                            val bytesRead = stream.read(buffer, 0, buffer.size)
                            if (bytesRead > 16) {
                                val carveResult = signatureEngine.identifySignature(buffer.copyOf(bytesRead), 0L)
                                val ext = carveResult?.extension ?: file.extension.ifEmpty { "bin" }
                                val mime = carveResult?.mimeType ?: "application/octet-stream"
                                val cat = carveResult?.category ?: ScanCategory.fromExtension(ext)
                                val hexHeader = carveResult?.hexHeader ?: buffer.take(16).joinToString(" ") { "%02X".format(it) }

                                val recoverable = RecoverableFile(
                                    id = UUID.randomUUID().toString(),
                                    name = if (source == FileSource.LOST_DIR && carveResult != null) {
                                        "${file.name}.${carveResult.extension}"
                                    } else {
                                        file.name
                                    },
                                    originalPath = file.absolutePath,
                                    uri = null,
                                    category = cat,
                                    mimeType = mime,
                                    extension = ext,
                                    sizeBytes = file.length(),
                                    source = source,
                                    confidence = carveResult?.confidence ?: RecoveryConfidence.MEDIUM,
                                    timestamp = file.lastModified(),
                                    hexSnippet = hexHeader
                                )

                                emit(recoverable)
                            }
                        } catch (e: Exception) {
                            // File might be locked or permission restricted
                        } finally {
                            stream?.close()
                        }
                    }
                }
        }
    }.flowOn(Dispatchers.IO)
}
