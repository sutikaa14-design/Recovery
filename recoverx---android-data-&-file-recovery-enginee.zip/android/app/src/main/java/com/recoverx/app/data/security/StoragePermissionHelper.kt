package com.recoverx.app.data.security

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

data class PermissionStatus(
    val hasAllFilesAccess: Boolean,
    val hasMediaImagesAccess: Boolean,
    val hasMediaVideosAccess: Boolean,
    val hasMediaAudioAccess: Boolean,
    val isLegacyStorageGranted: Boolean,
    val isRootAvailable: Boolean,
    val activeScanningTier: String
)

class StoragePermissionHelper(private val context: Context) {

    fun checkPermissionStatus(): PermissionStatus {
        val hasAllFiles = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

        val hasImages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            hasAllFiles
        }

        val hasVideos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            hasAllFiles
        }

        val hasAudio = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            hasAllFiles
        }

        val legacyGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED

        val isRoot = checkRootDetection()

        val activeTier = when {
            hasAllFiles -> "Tier 1: All Files & Deep Carving Access (Paling Lengkap)"
            hasImages || hasVideos || hasAudio -> "Tier 2: Scoped MediaStore & Trash Access"
            else -> "Tier 0: Belum Diberikan Izin"
        }

        return PermissionStatus(
            hasAllFilesAccess = hasAllFiles,
            hasMediaImagesAccess = hasImages,
            hasMediaVideosAccess = hasVideos,
            hasMediaAudioAccess = hasAudio,
            isLegacyStorageGranted = legacyGranted,
            isRootAvailable = isRoot,
            activeScanningTier = activeTier
        )
    }

    /**
     * Intent to open Android 11+ All Files Access settings for RecoverX.
     */
    fun createManageAllFilesIntent(): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
            } catch (e: Exception) {
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
            }
        } else null
    }

    private fun checkRootDetection(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }
        return false
    }
}
