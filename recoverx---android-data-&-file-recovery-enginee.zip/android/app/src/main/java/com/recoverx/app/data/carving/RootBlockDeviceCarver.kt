package com.recoverx.app.data.carving

import com.recoverx.app.data.model.FileSource
import com.recoverx.app.data.model.RecoverableFile
import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.UUID

class RootBlockDeviceCarver(
    private val signatureEngine: FileSignatureEngine
) {

    /**
     * When SuperUser / Root access is available, this engine bypasses Android's virtual
     * filesystem and directly carves deleted raw clusters from the physical eMMC / UFS partition:
     * e.g. /dev/block/bootdevice/by-name/userdata
     */
    fun scanRawPartition(
        blockDevicePath: String = "/dev/block/bootdevice/by-name/userdata",
        maxSectorsToCarve: Long = 100000L,
        onProgress: (sector: Long, path: String) -> Unit
    ): Flow<RecoverableFile> = flow {
        var process: Process? = null
        try {
            // Check su availability and dump sector chunks via dd or cat
            val cmd = arrayOf("su", "-c", "dd if=$blockDevicePath bs=4096 count=$maxSectorsToCarve 2>/dev/null")
            process = Runtime.getRuntime().exec(cmd)
            val inputStream = process.inputStream

            val buffer = ByteArray(8192)
            var currentSector = 0L
            var bytesRead: Int

            while (currentCoroutineContext().isActive) {
                bytesRead = inputStream.read(buffer, 0, buffer.size)
                if (bytesRead <= 0) break

                currentSector++
                if (currentSector % 200 == 0L) {
                    onProgress(currentSector, "$blockDevicePath @ sector $currentSector")
                }

                // Check signature at block boundary
                val result = signatureEngine.identifySignature(buffer.copyOf(bytesRead), currentSector * 4096)
                if (result != null && result.length > 512) {
                    emit(
                        RecoverableFile(
                            id = UUID.randomUUID().toString(),
                            name = "Raw_Carved_Sector_${currentSector}.${result.extension}",
                            originalPath = "$blockDevicePath [LBA: ${currentSector * 8}]",
                            uri = null,
                            category = result.category,
                            mimeType = result.mimeType,
                            extension = result.extension,
                            sizeBytes = result.length,
                            source = FileSource.FILE_CARVING,
                            confidence = result.confidence,
                            headerOffset = 0L,
                            length = result.length,
                            timestamp = System.currentTimeMillis(),
                            hexSnippet = result.hexHeader
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            process?.destroy()
        }
    }.flowOn(Dispatchers.IO)
}
