package com.recoverx.app.data.model

enum class ScanCategory(val displayName: String, val extensions: List<String>) {
    PHOTOS("Foto", listOf("jpg", "jpeg", "png", "webp", "heic", "gif", "dng", "bmp")),
    VIDEOS("Video", listOf("mp4", "mkv", "3gp", "mov", "avi", "webm", "flv")),
    AUDIO("Audio", listOf("mp3", "m4a", "wav", "aac", "ogg", "flac", "opus", "amr")),
    DOCUMENTS("Dokumen", listOf("pdf", "docx", "xlsx", "pptx", "txt", "csv", "epub")),
    ARCHIVES("Arsip ZIP/RAR", listOf("zip", "rar", "7z", "tar", "gz")),
    APKS("Aplikasi APK", listOf("apk", "xapk", "apks")),
    OTHERS("Lainnya", emptyList());

    companion object {
        fun fromExtension(ext: String): ScanCategory {
            val lower = ext.lowercase().trimStart('.')
            return entries.firstOrNull { it.extensions.contains(lower) } ?: OTHERS
        }

        fun fromMimeType(mime: String): ScanCategory {
            return when {
                mime.startsWith("image/") -> PHOTOS
                mime.startsWith("video/") -> VIDEOS
                mime.startsWith("audio/") -> AUDIO
                mime.contains("pdf") || mime.contains("document") || mime.contains("spreadsheet") || mime.contains("text/") -> DOCUMENTS
                mime.contains("zip") || mime.contains("rar") || mime.contains("tar") || mime.contains("compressed") -> ARCHIVES
                mime.contains("android.package-archive") -> APKS
                else -> OTHERS
            }
        }
    }
}
